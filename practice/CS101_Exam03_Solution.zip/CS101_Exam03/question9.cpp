#include <stdio.h>

#define MAX 100

int main(void) {
	double values[MAX];
	double weights[MAX];

	// TODO: prompt the user to enter how many values there will be
	int num_values;
	printf("How many values? ");
	scanf("%i", &num_values);
	if (num_values > MAX) {
		printf("Too many values\n");
		return 1;
	}

	// TODO: read values into the values array
	printf("Enter values: ");
	for (int i = 0; i < num_values; i++) {
		scanf("%lf", &values[i]);
	}

	// TODO: read weights into the weights array
	printf("Enter weights: ");
	for (int i = 0; i < num_values; i++) {
		scanf("%lf", &weights[i]);
	}

	// TODO: compute and print the weighted average
	double avg = 0.0;
	for (int i = 0; i < num_values; i++) {
		avg += (weights[i] * values[i]);
	}
	printf("Weighted average is %.2lf\n", avg);

	return 0;
}
