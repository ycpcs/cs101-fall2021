#include <stdio.h>

int main(void) {
	// TODO: add your code here

	return 0;
}
