#include <stdio.h>

#define MAX 100

int main(void) {
	double values[MAX];
	double weights[MAX];

	// TODO: prompt the user to enter how many values there will be

	// TODO: read values into the values array

	// TODO: read weights into the weights array

	// TODO: compute and print the weighted average

	return 0;
}
