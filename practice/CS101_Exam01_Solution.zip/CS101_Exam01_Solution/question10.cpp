#include <stdio.h>

int main(void) {
	// TODO: add your code here
	int k;

	printf("Enter an integer (2 <= k <= 12): ");
	scanf("%i", &k);

	if (k < 2 || k > 12) {

		printf("%i is an invalid input\n", k);

	} else {

		// Initially, assume that the number will not have any factors
		int has_factors = 0;

		if (k % 2 == 0) {
			printf("2 is a factor of %i\n", k);
			has_factors = 1;
		}
		if (k % 3 == 0) {
			printf("3 is a factor of %i\n", k);
			has_factors = 1;
		}
		if (k % 4 == 0) {
			printf("4 is a factor of %i\n", k);
			has_factors = 1;
		}
		if (k % 5 == 0) {
			printf("5 is a factor of %i\n", k);
			has_factors = 1;
		}
		if (k % 6 == 0) {
			printf("6 is a factor of %i\n", k);
			has_factors = 1;
		}
		// There can't be any factors greater than 6

		if (has_factors == 0) {
			printf("%i has no factors\n", k);
		}

	}

	return 0;
}
