#include <stdio.h>
#include <math.h>

int main(void) {
	// TODO: add your code here

	double a, b, c;

	printf("Enter a: ");
	scanf("%lf", &a);

	printf("Enter b: ");
	scanf("%lf", &b);

	printf("Enter c: ");
	scanf("%lf", &c);

	// this is the sqrt(b^2 -4ac) term
	double term = sqrt((b*b) - (4*a*c));

	double root1 = (-b + term) / (2*a);
	printf("Root = %.2lf\n", root1);

	double root2 = (-b - term) / (2*a);
	printf("Root = %.2lf\n", root2);

	return 0;
}
