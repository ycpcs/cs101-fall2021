#include <stdio.h>

int main(void) {
	// TODO: add your code here
	printf("Enter integers:\n");
	int even_count = 0;
	int keep_going = 1;
	while (keep_going == 1) {
		int value;
		scanf("%i", &value);
		if (value == -1) {
			keep_going = 0;
		} else if (value % 2 == 0) {
			even_count++;
		}
	}

	printf("Even integers: %i\n", even_count);

	return 0;
}
