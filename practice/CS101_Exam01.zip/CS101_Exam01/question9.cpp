#include <stdio.h>
#include <math.h>

int main(void) {
	// TODO: add your code here

	return 0;
}
