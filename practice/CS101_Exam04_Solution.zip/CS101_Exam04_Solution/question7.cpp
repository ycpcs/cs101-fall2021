#include <stdio.h>
#include <math.h>

#define MAX 100

// IMPORTANT: don't change the definition of the struct Point data type
struct Point {
	double x;
	double y;
};

double distance_between(struct Point a, struct Point b);
struct Point find_closest(struct Point points[], int num_points, struct Point target);

int main(void) {
	// IMPORTANT: do not modify any of the code in the main function.
	// If you do you will not receive any credit for this question.

	struct Point arr[MAX];
	struct Point target_pt, closest;
	int n;

	printf("How many points? ");
	scanf("%i", &n);

	if (n > MAX) {
		printf("Too many points\n");
		return 0;
	}

	printf("Enter x/y coordinates of points:\n");
	for (int i = 0; i < n; i++) {
		scanf("%lf %lf", &arr[i].x, &arr[i].y);
	}

	printf("Enter x/y coordinates of target point: ");
	scanf("%lf %lf", &target_pt.x, &target_pt.y);

	closest = find_closest(arr, n, target_pt);
	printf("Closest point to target is (%.2lf, %.2lf)\n", closest.x, closest.y);

	printf("Distance to closest point is %.2f\n", distance_between(closest, target_pt));

	return 0;
}

// TODO: write a definition for the distance_between function
double distance_between(struct Point a, struct Point b) {
	double xdiff = a.x - b.x;
	double ydiff = a.y - b.y;
	return sqrt(xdiff*xdiff + ydiff*ydiff);
}

// TODO: write a definition for the find_closest function
// Hint: the find_closest function should call the distance_between
// function
struct Point find_closest(struct Point points[], int num_points, struct Point target) {
	int best_index = 0;
	double best_dist = distance_between(target, points[0]);

	for (int i = 1; i < num_points; i++) {
		double dist = distance_between(target, points[i]);
		printf("Point (%.2lf, %.2lf): distance between is %.2lf\n",
			points[i].x, points[i].y, dist);
		if (dist < best_dist) {
			best_index = i;
			best_dist = dist;
		}
	}

	return points[best_index];
}
