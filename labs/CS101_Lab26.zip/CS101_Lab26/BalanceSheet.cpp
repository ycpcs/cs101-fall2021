#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FILENAME_MAXLEN 1024

// There will not be more than this many accounts
#define MAX_ACCOUNTS 20

int main(void) {
	char filename[FILENAME_MAXLEN];

	// Prompt the user to enter a filename
	printf("Load which file? ");
	fgets(filename, FILENAME_MAXLEN, stdin);
	char *nl = strrchr(filename, '\n');
	if (nl) {
		*nl = '\0';
	}

	// TODO: open the file for reading

	// TODO: read an integer, specifying how many accounts there are

	// TODO: initialize balances to 0

	// TODO: read each entry, adjusting the appropriate balance

	// TODO: close the file

	// TODO: print out the closing balances

	return 0;
}
