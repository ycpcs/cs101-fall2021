// CS101-101: Exam 3 Fall 2019 - Question 9
#include <stdio.h>
#include <math.h>

struct Point {
	double x, y;
};

#define MAX 100

// Function prototypes - DO NOT MODIFY
double findDistance(struct Point *p);
struct Point findFarthest(struct Point p[], int len);

// DO NOT MODIFY MAIN IN ANY WAY!
int main(void) {
	int num_points;
	struct Point points[MAX];
	
	printf("How many points? ");
	scanf("%i", &num_points);
	if (num_points > MAX) {
		printf("Too many points, sorry\n");
		return 1;
	}

	printf("Enter coordinates:\n");
	for (int i = 0; i < num_points; i++) {
		scanf("%lf %lf", &points[i].x, &points[i].y);
	}

	struct Point farthest;

	farthest = findFarthest(points,num_points);

	printf("Farthest point from origin is x=%lf, y=%lf\n", farthest.x, farthest.y);

	return 0;
}

// TODO: Add function definitions here
double findDistance(struct Point *p) {
	double distance = 0.0;

	return distance;
}

struct Point findFarthest(struct Point p[], int len) {
	struct Point farthest;
	
	return farthest;
}
