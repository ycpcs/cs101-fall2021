// CS101-101: Exam 3 Fall 2019 - Question 8
#include <stdio.h>

struct Corner {
	int x;
	int y;
};

struct Rect {
	struct Corner c1;
	struct Corner c2;
};

int computeArea(struct Rect *r);

int main() {
	struct Rect rectangle;
	
	// Obtain initial corners from user
	printf("Enter first corner coordinates: ");
	scanf("%i %i",&rectangle.c1.x,&rectangle.c1.y);
	printf("Enter second corner coordinates: ");
	scanf("%i %i",&rectangle.c2.x,&rectangle.c2.y);

	int area = 0.0;
	
	// TODO: Call computeArea function


	// Print area
	printf("Rectangle area = %i\n",area);

	return 0;
}

// TODO: Write a definition for the computeArea function
