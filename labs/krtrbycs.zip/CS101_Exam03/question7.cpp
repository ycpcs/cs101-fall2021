// CS101-101: Exam 3 Fall 2019 - Question 7
#include <stdio.h>

// IMPORTANT: do not modify the definition of struct Vec2
struct Vec2 {
	double x, y;
};

// TODO: add a prototype for the vec_add function

// IMPORTANT: do not modify the main function in any way
int main(void) {
	struct Vec2 a, b;

	printf("Enter x/y for first vector: ");
	scanf("%lf %lf", &a.x, &a.y);

	printf("Enter x/y for second vector: ");
	scanf("%lf %lf", &b.x, &b.y);

	struct Vec2 sum;
	sum = vec_add(a, b);

	printf("Result vector: x=%lf, y=%lf\n", sum.x, sum.y);
	return 0;
}

// TODO: add definition for the vec_add function

