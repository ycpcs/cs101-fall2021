// CS101-103: Final Exam Fall 2019 - Question 14
#include <stdio.h>

#define MAX 100

int check_palindrome(int numbers[], int n);

// IMPORTANT: do not modify the main function except where indicated below
// If you make any other modifications to main(), you will NOT receive any credit for this question.
int main(void) {

	int count;
	int seq[MAX];

	printf("How many numbers? ");
	scanf("%i", &count);

	printf("Enter a sequence of %i integers:\n", count);
	for (int i = 0; i < count; i++) {
		scanf("%i", &seq[i]);
	}

	int is_pal;
	
	// TODO: add a call to the check_palindrome() function
	
	
	if (is_pal == 0) {
		printf("Sequence is not a palindrome\n");
	} else if (is_pal == 1) {
		printf("Sequence is a palindrome\n");
	} else {
		printf("Unexpected return value\n");
	}
	return 0;
}

// TODO: write a definition of the check_palindrome function
